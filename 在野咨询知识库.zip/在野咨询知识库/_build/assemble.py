# -*- coding: utf-8 -*-
"""把 14 个片段输出装配成 6 个主题文件 + README；并抽取图片。"""
import os, re, zipfile, shutil

SRC = r"D:\PROJECT\Ds\_scratch\out"
DST = r"D:\PROJECT\Ds\在野咨询知识库"
DOCX = r"C:\Users\admin\.dsh\attachments\v1\files\f0\f07043253c0756601926149407131a909446bb3511174c0e30a1ebf74c6b7240\在野的咨询沉淀文档.docx"

CHAPTERS = {
    "01": ("基础政策与数据", [
        ("c01", "应届生身份与江苏升本赋分"),
        ("c06", "各省升本科目与分值"),
        ("c07", "专升本机会、四六级、C9 与专科考研"),
        ("c05", "雅思 8.0 的数据画像"),
    ]),
    "02": ("为什么学英语", [
        ("c04", "导师、大厂为什么看重英语"),
    ]),
    "03": ("升学路径与专业就业", [
        ("c10", "考研路线与方向选择"),
        ("c09", "专业就业地图：护理、法学与其他"),
    ]),
    "04": ("地域与考公", [
        ("c11", "地域产业结构与家长心智"),
        ("c12", "考公考编专题"),
    ]),
    "05": ("咨询流程与异议话术", [
        ("c01", "破冰：英语寒暄例句"),
        ("c08", "开场确认与整场主线框架"),
        ("c13", "性格分类、方法论与咨询稿五大模块"),
        ("c02", "异议处理与免费资源话术"),
        ("c03", "自学悖论与线上信任"),
        ("c14", "底层认知与促单"),
    ]),
    "06": ("素材库与自我训练", [
        ("c01", "素材缺口提醒：故事"),
        ("c08", "金句与故事"),
        ("c05", "讲课基本功与表达训练"),
        ("c06", "刻意练习与输出方法"),
    ]),
}

INTRO = {
    "01": "升学政策口径、各省考试科目、专升本与专科考研规则、难度对比数据——查数、核政策用这一份。",
    "02": "「为什么要学英语」的全部说服弹药：导师为什么卡英语、科研怎么入局、大厂与外企的门槛、四六级/考研/雅思的难度阶梯。",
    "03": "考研怎么讲、保研怎么塑造竞争、专业就业的真实分层（护理、法学为主，其余专业条目待补）。",
    "04": "全国各区域的产业底色、家长心智与切入方式，以及考公考编的分类、薪资差异、考试内容与英语价值。",
    "05": "咨询全流程：破冰、性格分类、咨询稿五大模块、各类异议处理、自学/信任/差评应对、促单逻辑。",
    "06": "金句、故事、讲课基本功与表达能力训练——平时积累、临场取用。",
}

# 每个源文件里，哪些 H2 归到哪个目标；不带星号的按前缀精确匹配
SECTION_ROUTE = {
    ("c01", "今天的整理任务"): "README",
    ("c01", "对于应届毕业生的定义"): "01",
    ("c01", "江苏升本的四级赋分"): "01",
    ("c01", "最近被严重漏掉的东西"): "06",
    ("c01", "和粉丝咨询可以举例的英语句子"): "05",
}
FULL = {"c02": "05", "c03": "05", "c04": "02", "c05": "06", "c06": "01", "c07": "01",
        "c08": "06", "c09": "03", "c10": "03", "c11": "04", "c12": "04", "c13": "05", "c14": "05"}
# c05 的雅思段挪去 01，其余留 06
SPECIAL = {("c05", "雅思 8.0 是什么概念"): "01",
           ("c06", "刻意练习的降维输出"): "06",
           ("c08", "开场：确认在宿舍还是自习室"): "05",
           ("c08", "了解环节与整场咨询的主线框架"): "05"}


def parse_md(path):
    lines = open(path, encoding="utf-8").read().splitlines()
    h1, pre, secs = None, [], []
    for ln in lines:
        if ln.startswith("# ") and h1 is None:
            h1 = ln[2:].strip()
            continue
        if ln.startswith("## "):
            secs.append([ln[3:].strip(), []])
        elif secs:
            secs[-1][1].append(ln)
        else:
            pre.append(ln)
    return h1, pre, secs


def route(src_tag, title):
    if (src_tag, title) in SPECIAL:
        return SPECIAL[(src_tag, title)]
    for (t, p), dest in SECTION_ROUTE.items():
        if t == src_tag and title.startswith(p):
            return dest
    return FULL.get(src_tag)


def demote(lines, by=1):
    out = []
    for ln in lines:
        m = re.match(r"^(#{1,6}) ", ln)
        if m:
            lvl = min(6, len(m.group(1)) + by)
            out.append("#" * lvl + ln[len(m.group(1)):])
        else:
            out.append(ln)
    return out


def main():
    if os.path.isdir(DST):
        for name in os.listdir(DST):
            p = os.path.join(DST, name)
            if name == "assets" and os.path.isdir(p):
                shutil.rmtree(p)
            elif name.endswith(".md"):
                os.remove(p)
    else:
        os.makedirs(DST)
    os.makedirs(os.path.join(DST, "assets"), exist_ok=True)

    # 图片
    z = zipfile.ZipFile(DOCX)
    for n in z.namelist():
        if n.startswith("word/media/"):
            base = os.path.basename(n)
            num = re.search(r"(\d+)", base).group(1)
            with open(os.path.join(DST, "assets", f"image{int(num):02d}.png"), "wb") as f:
                f.write(z.read(n))
    img_ok = len([f for f in os.listdir(os.path.join(DST, "assets"))])

    parsed = {}
    for i in range(1, 15):
        tag = f"c{i:02d}"
        parsed[tag] = parse_md(os.path.join(SRC, tag + ".md"))

    # 收集
    buckets = {k: [] for k in list(CHAPTERS.keys()) + ["README"]}
    for dest_key, (_title, chapters) in CHAPTERS.items():
        for tag, chap_title in chapters:
            h1, pre, secs = parsed[tag]
            got = [s for s in secs if route(tag, s[0]) == dest_key]
            if not got:
                continue
            body = []
            for t, lines in got:
                body.append("### " + t)
                body.extend(demote(lines))
                body.append("")
            buckets[dest_key].append((chap_title, body))
    # README 收 c01 待办
    h1, pre, secs = parsed["c01"]
    for t, lines in secs:
        if route("c01", t) == "README":
            buckets["README"].append((t, demote(lines)))

    toc_all = []
    for key, (title, _chs) in CHAPTERS.items():
        fname = f"{key}-{title}.md"
        body = [f"# {title}", "", f"> {INTRO[key]}", "", "---", ""]
        for chap_title, lines in buckets[key]:
            body.append(f"## {chap_title}")
            body.append("")
            body.extend(lines)
            body.append("")
        text = "\n".join(body)
        text = re.sub(r"\[\[IMG(\d+):media/[^\]]+\]\]", lambda m: f"![图{m.group(1)}](assets/image{int(m.group(1)):02d}.png)", text)
        text = re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"
        open(os.path.join(DST, fname), "w", encoding="utf-8").write(text)
        toc_all.append((fname, title, [l[3:].strip() for l in text.splitlines() if l.startswith("## ")]))
        print(fname, len(re.sub(r"\s", "", text)))

    # README
    rd = ["# 在野咨询知识库", "",
          "由《在野的咨询沉淀文档.docx》（岑啟艳-咨询促单沉淀，2026-11 版，约 1900 段原始笔记）整理而来。",
          "整理原则：**只做结构化，不改内容**——原文逐句保留，只加标题、归并同类条目、拆开被硬回车打断的句子、去掉完全重复的句子。",
          "", "## 怎么用", "",
          "- 查政策/考试科目 → `01`；想说服学员为什么要学英语 → `02`；讲考研、讲专业出路 → `03`；按地域/考公切入 → `04`；",
          "- 临场话术、异议处理、促单 → `05`；金句、故事、自我训练 → `06`。",
          "- 每个文件顶部有一句话定位，正文按「章 → 话题」两级标题组织，编辑器大纲里可直接跳转。",
          "", "## 目录", ""]
    for fname, title, h2s in toc_all:
        rd.append(f"### [{title}]({fname})")
        rd.append("")
        for h in h2s:
            rd.append(f"- {h}")
        rd.append("")
    rd += ["## 原始待办（2026-11 笔记开头记的）", ""]
    for t, lines in buckets["README"]:
        rd.extend([l for l in lines if l.strip()])
    rd += ["", "## 整理说明", "",
           f"- 原文 1939 段、约 9.4 万字、14 张插图（已抽取到 `assets/`，按出现顺序编号）。",
           "- 原文没有任何标题样式，全部是「正文」段落；本次按语义补了层级标题，这是最大的改动。",
           "- 完全重复的句子只删了 1 处（专业列表里重复的「体育」），其余一字未删。",
           "- 原文有 1 张表格（考公艰苦边远地区分类），已转成 Markdown 表格。",
           "- 原始 docx 未改动，副本放在本目录 `原件-在野的咨询沉淀文档.docx`，需要回退或重新整理时以它为源。",
           "- `_build/` 是整理过程文件：按原文顺序切的 14 个片段、每段的结构化结果、装配脚本 `assemble.py`。原文更新后可据此重跑。"]
    open(os.path.join(DST, "README.md"), "w", encoding="utf-8").write("\n".join(rd) + "\n")
    print("README.md", "images", img_ok)


if __name__ == "__main__":
    main()
